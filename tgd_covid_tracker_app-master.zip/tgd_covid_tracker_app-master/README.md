# TGD COVID TRACKER
An open-sourced Mobile application to track the COVID-19 cases made using Flutter. Complete applicaion with crisp UI and full API Integration.

![Branch master](https://img.shields.io/badge/branch-master-brightgreen.svg?style=flat-square)  [![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](https://raw.githubusercontent.com/singh-saheb/tgd_covid_tracker_app/master/LICENSE)

![alt text](/ss1.png) ![alt text](/covid-dark.png) 
![alt text](/covid-search.png) 


# Features:

  - Get worldwide COVID-19 cases
  - Coutry-wise data
  - Added Dark mode 
  - Realtime search based on country name

# Coming soon:
  - Data to be shown in the form of pie chart
